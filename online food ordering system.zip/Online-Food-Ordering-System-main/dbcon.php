<?php
	
	$conn = mysqli_connect('localhost','root','','gautam_foods');

	if ($conn == false) 
	{
		echo "Database connection failed";
	}
?>