<?php
	include('session_start.php');
	$conn = mysqli_connect('localhost','root','','gautam_foods');

	if ($conn == false) 
	{
		echo "Database connection failed";
	}
   
$menu_items = [
    1 => ["name" => "Chai Bhajya", "price" => 12.99],
    2 => ["name" => "Daalwada", "price" => 8.99],
    3 => [ "name" => "Jalebi Samosha", "price" => 10.99],
    4 => ["name" => "chana salad", "price" => 15.99],
    5 => ["name" => "jeri Puri Tarkari", "price" => 20.99],
    6=> ["name" => "poha upma", "price" => 8.99],
    7=> ["name" => "Pasta", "price" => 10.99],
    8=>[ "name" => "Jalebi Samosha", "price" => 30.99],
    9=>[ "name" => "Naan", "price" => 12.99],
       10=>  ["name" => "Daalchaawalroti", "price" => 12.99],
    11=> [ "name" => "Chicken Chawal", "price" => 20.99],
    12=> [ "name" => "Chicken-Pulao", "price" => 30.99],
      
       13 =>  ["name" => "Dal-Chawal-Aloo-ki-Bhunjia", "price" => 8.99],
    14=>  ["name" => "Daal-Rice-Ghee", "price" => 12.99],
    15   => [ "name" => "Egg Biryani", "price" => 15.99],
    16=> [ "name" => "Eggs Chaawal", "price" => 20.99],
    17=> [ "name" => "Gur-walay-Chawal", "price" => 10.99],
    18=> [ "name" => "Fish fry", "price" => 10.99],
    19=> [ "name" => "Daalchaawalroti", "price" => 12.99],
   20 => [ "name" => "Chicken Chawal", "price" => 20.99],
    21=> [ "name" => "Chicken-Pulao", "price" => 30.99],
    22=> [ "name" => "Dal-Chawal-Aloo-ki-Bhunjia ", "price" => 8.99],
    23=> [ "name" => "Daal-Rice-Ghee ", "price" => 12.99],
   24 => [ "name" => "Egg Biryani", "price" => 15.99],
    25=> [ "name" => "Eggs Chaawal", "price" => 20.99],
    26=> [ "name" => "Gur-walay-Chawal", "price" => 10.99]
];

$total = 0;
?>
<!DOCTYPE html>
<html>
<head>
<style>
    .navbar {
display: flex;
justify-content: space-between;
align-items: center;
padding: 1rem;
font-size: 15px;
background-color: #333;
color: white;
}
.container{
    font-size:20px;
    width:450px;
    color:white;
    text-align:center;
    height:400px;
    background: #34546355;
    border: 2px solid yellow;
    border-radius:10px;
}
.container a{
    color:yellow;
}
.brand-title {
font-size: 1.5rem;
font-size: 20px;
color:yellow;
}
.navbar-links ul {
list-style: none;
display: flex;
}
.navbar-links li {
margin-left: 1rem;
}

.navbar-links a {
color: #fff;
text-decoration: none;
font-size: 1rem;
font-size: 15px;
}

.navbar-links ul.active {
display: flex;
}

.navbar-links li {
text-align: center;
padding: 0.5rem 0;
width: 100%;
}
</style>
    
    <title>Cart</title>
    <link href="cartcss.css" rel="stylesheet">
</head>
<body>
<nav class="navbar">
    <div class="brand-title">gautam foods deliveroo</div>
   
    <div class="navbar-links">
      <ul>
      <li><a href="cart.php">cart</a></li>
        <li><a href="menu.php">Menu</a></li>
       
        <li><a href="add product into cart.php">yourorder</a></li>
        <li><a href="portfolio.php">portfolio</a></li>
      </ul>
    </div>
  </nav><center>
    <div class="container">
    <h1>Your Cart</h1>
    <ul>
        <?php foreach ($_SESSION['cart'] as $item_id => $quantity): ?>
            <li>
                <?= $menu_items[$item_id]['name'] ?> x <?= $quantity ?> = $<?= number_format($menu_items[$item_id]['price'] * $quantity, 2) ?>
                <?php $total += $menu_items[$item_id]['price'] * $quantity; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <p>Total: $<?= number_format($total, 2) ?></p>
    
    <p><a href="cart.php">Continue Shopping</a></p>
    <p><a href="http://localhost/Online-Food-Ordering-System-main/confirmorder.php">Proceed to Checkout</a></p>
        </div></center>
        <?php
        include ('footer.php');?>
</body>
</html>
