<?php
include('session_start.php');
$menu_items = [
    1 => ["name" => "Chai Bhajya", "price" => 12.99],
    2 => ["name" => "Daalwada", "price" => 8.99],
    3 => [ "name" => "Jalebi Samosha", "price" => 10.99],
    4 => ["name" => "chana salad", "price" => 15.99],
    5 => ["name" => "jeri Puri Tarkari", "price" => 20.99],
    6=> ["name" => "poha upma", "price" => 8.99],
    7=> ["name" => "Pasta", "price" => 10.99],
    8=>[ "name" => "Jalebi Samosha", "price" => 30.99],
    9=>[ "name" => "Naan", "price" => 12.99],
       10=>  ["name" => "Daalchaawalroti", "price" => 12.99],
    11=> [ "name" => "Chicken Chawal", "price" => 20.99],
    12=> [ "name" => "Chicken-Pulao", "price" => 30.99],
      
       13 =>  ["name" => "Dal-Chawal-Aloo-ki-Bhunjia", "price" => 8.99],
    14=>  ["name" => "Daal-Rice-Ghee", "price" => 12.99],
    15   => [ "name" => "Egg Biryani", "price" => 15.99],
    16=> [ "name" => "Eggs Chaawal", "price" => 20.99],
    17=> [ "name" => "Gur-walay-Chawal", "price" => 10.99],
    18=> [ "name" => "Fish fry", "price" => 10.99],
    19=> [ "name" => "Daalchaawalroti", "price" => 12.99],
   20 => [ "name" => "Chicken Chawal", "price" => 20.99],
    21=> [ "name" => "Chicken-Pulao", "price" => 30.99],
    22=> [ "name" => "Dal-Chawal-Aloo-ki-Bhunjia ", "price" => 8.99],
    23=> [ "name" => "Daal-Rice-Ghee ", "price" => 12.99],
   24 => [ "name" => "Egg Biryani", "price" => 15.99],
    25=> [ "name" => "Eggs Chaawal", "price" => 20.99],
    26=> [ "name" => "Gur-walay-Chawal", "price" => 10.99]
];

$total = 0;
?>
<!DOCTYPE html>
<html>
<head>
   <style>
   h1{
    color:red;
   }
   .receipt{
    font-size:20px;
    width:450px;
    text-align:center;
    height:400px;
    background: #34546355;
    border: 2px solid yellow;
    border-radius:10px;
   }
   button{
    color:white;
    font-size:25px;
    background: yellow;
    width: 80px;
    border-radius:10px;
   }
   
  </style>
    <title>Receipt</title>

    <link rel="stylesheet" href="footerheader.css" />
</head>
<body>  <nav class="navbar">
    <div class="brand-title">gautam foods deliveroo</div>
   
    <div class="navbar-links">
      <ul>
      <li><a href="cart.php">cart</a></li>
        <li><a href="menu.php">Menu</a></li>
       
        <li><a href="http://localhost/Online-Food-Ordering-System-main/admin/customerdb.php">yourorder</a></li>
        <li><a href="portfolio.php">portfolio</a></li>
      </ul>
    </div>
  </nav><br>
  <center>
  <div class="receipt">
  
    <h1>Order Receipt</h1><br>
    <ol>
        <?php foreach ($_SESSION['cart'] as $item_id => $quantity): ?>
            <li>
                <?= $menu_items[$item_id]['name'] ?> x <?= $quantity ?> = $<?= number_format($menu_items[$item_id]['price'] * $quantity, 2) ?>
                <?php $total += $menu_items[$item_id]['price'] * $quantity; ?>
            </li>
        <?php endforeach; ?>
    </ol><br><br>
    <p>Total: $<?= number_format($total, 2) ?></p><br><br>
    <p>Thank you for your order!</p>

    <?php
    // Clear cart after displaying receipt
    $_SESSION['cart'] = [];
  
   ?><br>
   
</div></center>
<br><br><br><br>
<br><br><br><br>
   <?php
   include ('footer.php');?>
   
</body>
</html>
