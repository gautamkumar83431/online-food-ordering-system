<?php
	
	$conn = mysqli_connect('localhost','root','','gautam_foods');

	if ($conn == false) 
	{
		echo "Database connection failed";
	}
  $menu_items = [
    ["id" => 1, "name" => "Chai Bhajya", "price" => 12.99],
   // ["id" => 2, "name" => "Pizza", "price" => 7.99],
   // ["id" => 3, "name" => "Pasta", "price" => 6.99],
 ];
 $menu_items1 = [
    ["id" => 2, "name" => "Daalwada", "price" => 8.99]
 ];
 $menu_items2 = [
    ["id" => 3, "name" => "Jalebi Samosha", "price" => 10.99]
 ];
 $menu_items3 = [
    ["id" => 4, "name" => "chana salad", "price" => 15.99]
 ];
 $menu_items4 = [
    ["id" => 5, "name" => "jeri Puri Tarkari", "price" => 20.99]
 ];
 $menu_items5 = [
    ["id" => 6, "name" => "poha upma", "price" => 8.99]
 ];
 $menu_items6 = [
    ["id" => 7, "name" => "Pasta", "price" => 10.99]
 ];
 $menu_items7 = [
    ["id" => 8, "name" => "Jalebi Samosha", "price" => 30.99]
 ];
 $menu_items8 = [
    ["id" => 9, "name" => "Naan", "price" => 12.99]
 ];
 $menu_items9 = [
    ["id" => 10, "name" => "Daalchaawalroti", "price" => 12.99]
 ];
 $menu_items10 = [
    ["id" => 11, "name" => "Chicken Chawal", "price" => 20.99]
 ];
 $menu_items11 = [
    ["id" => 12, "name" => "Chicken-Pulao", "price" => 30.99]
 ];
 $menu_items12 = [
    ["id" => 13, "name" => "Dal-Chawal-Aloo-ki-Bhunjia", "price" => 8.99]
 ];
 $menu_items13 = [
    ["id" => 14, "name" => "Daal-Rice-Ghee", "price" => 12.99]
 ];
 $menu_items14 = [
    ["id" => 15, "name" => "Egg Biryani", "price" => 15.99]
 ];
 $menu_items15 = [
    ["id" => 16, "name" => "Eggs Chaawal", "price" => 20.99]
 ];
 $menu_items16 = [
    ["id" => 17, "name" => "Gur-walay-Chawal", "price" => 10.99]
 ];
 $menu_items17 = [
    ["id" => 18, "name" => "Fish fry", "price" => 10.99]
 ];
 $menu_items18 = [
    ["id" => 19, "name" => "Daalchaawalroti", "price" => 12.99]
 ];
 $menu_items19 = [
    ["id" => 20, "name" => "Chicken Chawal", "price" => 20.99]
 ];
 $menu_items20 = [
    ["id" => 21, "name" => "Chicken-Pulao", "price" => 30.99]
 ];
 $menu_items21 = [
    ["id" => 22, "name" => "Dal-Chawal-Aloo-ki-Bhunjia ", "price" => 8.99]
 ];
 $menu_items22 = [
    ["id" => 23, "name" => "Daal-Rice-Ghee ", "price" => 12.99]
 ];
 
 $menu_items23 = [
    ["id" => 24, "name" => "Egg Biryani", "price" => 15.99]];
 $menu_items24 = [
    ["id" => 25, "name" => "Eggs Chaawal", "price" => 20.99]
 ];
 $menu_items25 = [
    ["id" => 26, "name" => "Gur-walay-Chawal", "price" => 10.99]
 ];
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
         .navbar {
display: flex;
justify-content: space-between;
align-items: center;
padding: 1rem;
font-size: 15px;
background-color: #333;
color: white;
}

.brand-title {
font-size: 1.5rem;
font-size: 20px;
color:yellow;
}

.navbar-links ul {
list-style: none;
display: flex;

}

.navbar-links li {
margin-left: 1rem;
}

.navbar-links a {
color: #fff;
text-decoration: none;
font-size: 1rem;
font-size: 15px;
}





.navbar-links ul.active {
display: flex;
}

.navbar-links li {
text-align: center;
padding: 0.5rem 0;
width: 100%;
}   

.container {
  justify-content: space-around;
  flex-wrap: wrap;
    background-color: rgb(218, 159, 159);
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: flex;
    width: 100%;
}

h1 {
    text-align: center;
    color: #160404;
}

.menu {
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
    flex-wrap: wrap;
}



.menu-item {
  background-color: white;
  padding: 20px;
  margin: 10px;
  text-align: center;
  cursor: pointer;
width: 300px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

}
.menu-item:hover{
  transform: scale(1.07);
}
.menu-item img {
  width: 100%;
  height: auto;
  border-radius: 8px;
}
.menu-item h2 {
    font-size: 20px;
    color: #000000;
}

.menu-item p {
    font-size: 16px;
    color: #555050;
}

.menu-item button {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 8px 12px;
    cursor: pointer;
    border-radius: 4px;
    margin-top: 10px;
}

.menu-item button:hover {
    background-color: #218838;
}

.order-summary {
    border-top: 2px solid #e9e9e9;
    padding-top: 20px;
}

.order-summary h2 {
    font-size: 25px;
    color: #f90505;
    margin-bottom: 15px;
}

#orderList {
    list-style: none;
    padding: 0;
    margin: 0;
    margin-bottom: 20px;
}

#orderList li {
    font-size: 20px;
    color: rgb(0, 0, 0);
    margin-bottom: 5px;
}

#total {
    font-size: 20px;
    font-weight: bold;
    color: #333;
    margin-bottom: 20px;
}

#checkoutBtn {
    width: 100%;
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 0;
    font-size: 18px;
    cursor: pointer;
    border-radius: 4px;
}

#checkoutBtn:hover {
    background-color: #0069d9;
}
.price {
  font-size: 1.5em;
  color: #e67e22;
  margin-top: 10px;
}

    </style>
</head>
<body>
<nav class="navbar">
    <div class="brand-title">gautam foods deliveroo</div>
   
    <div class="navbar-links">
      <ul>
      <li><a href="cart.php">cart</a></li>
        <li><a href="menu.php">Menu</a></li>
       
        <li><a href="add product into cart.php">yourorder</a></li>
        <li><a href="portfolio.php">portfolio</a></li>
      </ul>
    </div>
  </nav>
  <br><br><br>
    <div class="container">
        <h1>Order Your Food</h1><br>
        <section class="menu">
    <div class="menu-item">
        <h2>Chai Bhajya</h2>
        <img src="morning nasta/chai bhagia.jpg" alt="chai bhajiya">
        <p>Morning Nasta of Chai with bhajiya , Hari  mirchi  and  Chutni. 😋😋😋 </p>
        <span class="price">$12.99</span>
       <ul>
        <?php foreach ($menu_items as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
        <h2>Daalwada</h2>
        <img src="morning nasta/dalwada.jpg" alt="Daalwada">
        <p> Morning Nasta of Daalwada with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$8.99</span>
        <ul>
        <?php foreach ($menu_items1 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
        <h2>Jalebi Samosha</h2>
        <img src="morning nasta/jalebi samosha.jpg" alt="jalebi samosha">
        <p>Morning Morning Nasta of Jalebi ,Samosha with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$10.99</span>
        <ul>
        <?php foreach ($menu_items2 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
      <h2>chana salad</h2>
      <img src="morning nasta/chana salad.jpg" alt="chana salad">
      <p> Morning Nasta of chana salad with tomato , Hari mirchi and Onion. 😋😋 </p>
      <span class="price">$15.99</span>
      <ul>
        <?php foreach ($menu_items3 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
  </div>
  <div class="menu-item">
    <h2>jeri Puri Tarkari</h2>
    <img src="morning nasta/jeri Puri Tarkari.jpg" alt="jeri Puri Tarkari">
    <p> Morning Nasta of jeri Puri Tarkari with Chutni , Hari mirchi and Onion. 😋😋 </p>
    <span class="price">$20.99</span>

    <ul>
        <?php foreach ($menu_items4 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>poha upma</h2>
  <img src="morning nasta/poha upma.jpg" alt="poha upma ">
  <p> Morning Nasta of poha upma  with , Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$8.99</span>
  <ul>
        <?php foreach ($menu_items5 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Pasta</h2>
  <img src="morning nasta/pasta.webp" alt="Pasta ">
  <p> Morning Nasta of Pasta  with Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$10.99</span>
  <ul>
        <?php foreach ($menu_items6 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<<div class="menu-item">
  <h2>Jalebi Samosha</h2>
  <img src="morning nasta/samosa.jpg" alt="jalebi samosha">
  <p> Morning Nasta of samosha, Chutni and hary mirch. 😋😋 </p>
  <span class="price">$30.99</span>
  <ul>
        <?php foreach ($menu_items7 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Naan </h2>
  <img src="morning nasta/naan.jpg" alt="jalebi samosha">
  <p> Morning Nasta Naan is a leavened, oven-baked flatbread. 😋😋 </p>
  <span class="price">$12.99</span>
  <ul>
        <?php foreach ($menu_items8 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
 
</div>
</section>
<div class="menu1">
  <h1>MENU</h1>
   
   <h1 style="color: red;">LUNCH AND DINNER</h1>
    <p>Explore our delicious menu</p>
</div>
  <section class="menu">
    <div class="menu-item">
        <h2>Daalchaawalroti</h2>
        <img src="morning nasta/daalchaawalroti.jpg" alt="daalchaawalroti">
        <p>Lunch  of Daal Chaawal Roti Hari  mirchi  and  Onion. 😋😋😋 </p>
        <span class="price">$12.99</span>
        <ul>
        <?php foreach ($menu_items9 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
        <h2>Chicken Chawal</h2>
        <img src="morning nasta/chicken chawal.jpg" alt="chicken chawal">
        <p>Chicken Chawal with  Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$20.99</span>
        <ul>
        <?php foreach ($menu_items10 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
        <h2>Chicken-Pulao</h2>
        <img src="morning nasta/Chicken-Pulao.jpg" alt="Chicken-Pulao ">
        <p>Chicken-Pulao with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$30.99</span>
        <ul>
        <?php foreach ($menu_items11 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
    </div>
    <div class="menu-item">
      <h2>Dal-Chawal-Aloo-ki-Bhunjia</h2>
      <img src="morning nasta/Dal-Chawal-Aloo-ki-Bhunjia.webp" alt="Dal-Chawal-Aloo-ki-Bhunjia ">
      <p> Dal-Chawal-Aloo-ki-Bhunjia Hari mirchi and Onion. 😋😋 </p>
      <span class="price">$8.99</span>
      <ul>
        <?php foreach ($menu_items12 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
  </div>
  <div class="menu-item">
    <h2>Daal-Rice-Ghee</h2>
    <img src="morning nasta/dal-rice-ghee.jpg" alt="dal-rice-ghee">
    <p> Daal-Rice-Ghee Hari mirchi and Onion. 😋😋 </p>
    <span class="price">$12.99</span>
    <ul>
        <?php foreach ($menu_items13 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Egg Biryani</h2>
  <img src="morning nasta/Egg Biryani.jpg" alt="Egg Biryani ">
  <p>Egg Biryani Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$15.99</span>
  <ul>
        <?php foreach ($menu_items14 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Eggs Chaawal</h2>
  <img src="morning nasta/eggs chawal.jpg" alt="Egg chaawal ">
  <p> Eggs Chaawal with Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$20.99</span>
  <ul>
        <?php foreach ($menu_items15 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Gur-walay-Chawal</h2>
  <img src="morning nasta/Gur-walay-Chawal.webp" alt="Gur-walay-Chawal">
  <p>Gur-walay-Chawal 😋😋 </p>
  <span class="price">$10.99</span>
  <ul>
        <?php foreach ($menu_items16 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
<div class="menu-item">
  <h2>Fish fry</h2>
  <img src="morning nasta/fish.jpg" alt="Gur-walay-Chawal">
  <p>Fish fry is a meal containing battered or breaded fried fish. 😋😋 </p>
  <span class="price">$10.99</span>
  <ul>
        <?php foreach ($menu_items17 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
</div>
</section>

        <div class="menu">
            <div class="menu-item">
                <h2>Daalchaawalroti</h2>
                <img src="morning nasta/daalchaawalroti.jpg" alt="daalchaawalroti">
                <p>Lunch  of Daal Chaawal Roti Hari  mirchi  and  Onion. 😋😋😋 </p>
                <span class="price">$12.99</span>
                <ul>
        <?php foreach ($menu_items18 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
              
            </div>
            <div class="menu-item">
              <h2>Chicken Chawal</h2>
              <img src="morning nasta/chicken chawal.jpg" alt="chicken chawal">
              <p>Chicken Chawal with  Hari mirchi and Onion. 😋😋 </p>
              <span class="price">$20.99</span>
              <ul>
        <?php foreach ($menu_items19 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
          </div>
          <div class="menu-item">
              <h2>Chicken-Pulao</h2>
              <img src="morning nasta/Chicken-Pulao.jpg" alt="Chicken-Pulao ">
              <p>Chicken-Pulao with Chutni , Hari mirchi and Onion. 😋😋 </p>
              <span class="price">$30.99</span>
              <ul>
        <?php foreach ($menu_items20 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
          </div>
          <div class="menu-item">
            <h2>Dal-Chawal-Aloo-ki-Bhunjia</h2>
            <img src="morning nasta/Dal-Chawal-Aloo-ki-Bhunjia.webp" alt="Dal-Chawal-Aloo-ki-Bhunjia ">
            <p> Dal-Chawal-Aloo-ki-Bhunjia Hari mirchi and Onion. 😋😋 </p>
            <span class="price">$8.99</span>
            <ul>
        <?php foreach ($menu_items21 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
        </div>
        <div class="menu-item">
            <h2>Daal-Rice-Ghee</h2>
            <img src="morning nasta/dal-rice-ghee.jpg" alt="dal-rice-ghee">
            <p> Daal-Rice-Ghee Hari mirchi and Onion. 😋😋 </p>
            <span class="price">$12.99</span>
            <ul>
        <?php foreach ($menu_items22 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
        </div>
        <div class="menu-item">
            <h2>Egg Biryani</h2>
            <img src="morning nasta/Egg Biryani.jpg" alt="Egg Biryani ">
            <p>Egg Biryani Hari mirchi and Onion. 😋😋 </p>
            <span class="price">$15.99</span>
            <ul>
        <?php foreach ($menu_items23 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
          </div>
          <div class="menu-item">
            <h2>Eggs Chaawal</h2>
            <img src="morning nasta/eggs chawal.jpg" alt="Egg chaawal ">
            <p> Eggs Chaawal with Hari mirchi and Onion. 😋😋 </p>
            <span class="price">$20.99</span>
            <ul>
        <?php foreach ($menu_items24 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
          </div>
          <div class="menu-item">
            <h2>Gur-walay-Chawal</h2>
            <img src="morning nasta/Gur-walay-Chawal.webp" alt="Gur-walay-Chawal">
            <p>Gur-walay-Chawal 😋😋 </p>
            <span class="price">$10.99</span>
            <ul>
        <?php foreach ($menu_items25 as $item): ?>
            <li>
           
                <?= $item['name'] ?> - $<?= number_format($item['price'], 2) ?>
                <form action="order.php" method="POST">
               
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1">
                 
                    <button type="submit">Add to Cart</button>
                </form>
            </li>
          
          
        <?php endforeach; ?>
          </div>
        </div>
<?php 
include ('footer.php');?>
</body>
</html>
