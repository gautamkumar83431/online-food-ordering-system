<style>
    .footer .top {
    background-color: #656654;
    padding: 10rem 9%;
  
    display: grid;
    grid-template-columns: 1fr 2fr;
  }
  
  .footer .top .links {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 3rem;
  }
  
  .footer .bottom {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1.5rem 0;
    background-color: var(--deep-yellow);
  }
  
  .footer .top .content p {
    color: var(--grey);
    margin-top: 2rem;
    width: 90%;
  }
  
  .footer .top .link h4 {
    font-size: 1.7rem;
    margin-bottom: 1.5rem;
  }
  
  .footer .top .link a {
    display: inline-block;
    color: var(--grey);
    margin-bottom: 1rem;
  }
  
  .footer .top .link span {
    color: var(--grey);
  }
  
  .footer .top .link a {
    display: block;
  }
  
  .footer .top .link div {
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
  }
  
  .footer .top .link div img {
    margin-right: 1rem;
  }
  @media (max-width: 996px) {
    .footer .top {
      padding: 5rem 9%;
      grid-template-columns: 1fr;
    }
  
    .footer .top .content {
      display: none;
    }
  }
  
  @media (max-width: 768px) {
    .footer .top .links {
      grid-template-columns: 1fr;
      gap: 3rem 0;
    }
  
    .footer .top .link {
      display: flex;
      flex-direction: column;
    }
  
    .footer .bottom {
      padding: 1.5rem;
    }
  }
</style>
<footer class="footer">
        <div class="top">
          <div class="content">
            <a href="" class="logo">Delive<span class="yellow">roo</span></a>
           
          </div>
  
          <div class="links">
            <div class="link">
              <h4>Contact Information</h4>
              <div>
                <img src="location-cross.svg" alt="" />
                <span>Patna,(Bihar),800004</span>
              </div>
              <div>
                <img src="sms-tracking.svg" alt="" />
                <span>deliveroo@gmail.com</span>
              </div>
            </div>
  
            <div class="link">
              <h4>Quick Links</h4>
              <a href="#">Services</a>
              <a href="#">About Us</a>
              <a href="#">Contact Us</a>
              <a href="#">Download</a>
            </div>
  
            <div class="link">
              <h4>Legal</h4>
              <a href="#">Privacy Policy</a>
              <a href="#">Term of Use</a>
              <a href="#">Conditions</a>
              <a href="#">Location</a>
            </div>
  
            <div class="link">
              <h4>Connect with Us</h4>
              <div>
                <img src="instagram.svg" alt="" />
                <span>Instagram</span>
              </div>
              <div>
                <img src="twitter.svg" alt="" />
                <span>Twitter</span>
              </div>
              <div>
                <img src="facebook.svg" alt="" />
                <span>Facebook</span>
              </div>
            </div>
          </div>
        </div>
        <div class="bottom">
          <p>Copyright © 20120-2025 Deliveroo Company  All rights reserved.</p>
        </div>
      </footer>