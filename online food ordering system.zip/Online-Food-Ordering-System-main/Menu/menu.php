<?php
	
	$conn = mysqli_connect('localhost','root','','gautam_foods');

	if ($conn == false) 
	{
		echo "Database connection failed";
	}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Deliveroo</title>
    <!-- StyleSheets -->
    <link rel="stylesheet" href="foodfair.css" />
  </head>
  <body>
  <header class="header">
        <a href="/" class="logo">Delive<span class="yellow">roo</span></a>
      
        <nav class="navbar">
        
            <a href="#services">Services</a>
            <a href="#about">About Us</a>
            <a href="#contact">Contact Us</a>
            <a href="" class="btn">Make an Order</a>
          </nav>
          <div class="hamburger">
            <img src="grid-outline.svg" alt="" />
          </div> 
  </header><br><br>
<div class="menu1">
 
  <li> <a  href="portfolio.php" class="fairfoode">Click Here Go TO My Portfolio.</a></li>
 <br><br><br>
  <h1>MENU</h1>
    <h1 class="h11">Welcome to Our Restaurant</h1>
   <h1 style="color: red;">MORNING NASTA</h1>
    <p>Explore our delicious menu</p>
</div>

  <section class="menu">
    <div class="menu-item">
        <h2>Chai Bhajya</h2>
        <img src="morning nasta/chai bhagia.jpg" alt="chai bhajiya">
        <p>Morning Nasta of Chai with bhajiya , Hari  mirchi  and  Chutni. 😋😋😋 </p>
        <span class="price">$12.99</span>
      
     
    </ul>  <button class="order-btn"><a href="cart.php">Order Now</a></button>
    </div>
    <div class="menu-item">
        <h2>Daalwada</h2>
        <img src="morning nasta/dalwada.jpg" alt="Daalwada">
        <p> Morning Nasta of Daalwada with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$8.99</span>
        <button class="order-btn"><a href="cart.php">Order Now</button>
    </div>
    <div class="menu-item">
        <h2>Jalebi Samosha</h2>
        <img src="morning nasta/jalebi samosha.jpg" alt="jalebi samosha">
        <p>Morning Morning Nasta of Jalebi ,Samosha with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$10.99</span>
        <button class="order-btn"><a href="cart.php">Order Now</button>
    </div>
    <div class="menu-item">
      <h2>chana salad</h2>
      <img src="morning nasta/chana salad.jpg" alt="chana salad">
      <p> Morning Nasta of chana salad with tomato , Hari mirchi and Onion. 😋😋 </p>
      <span class="price">$15.99</span>
      <button class="order-btn"><a href="cart.php">Order Now</button>
  </div>
  <div class="menu-item">
    <h2>jeri Puri Tarkari</h2>
    <img src="morning nasta/jeri Puri Tarkari.jpg" alt="jeri Puri Tarkari">
    <p> Morning Nasta of jeri Puri Tarkari with Chutni , Hari mirchi and Onion. 😋😋 </p>
    <span class="price">$20.99</span>
    <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>poha upma</h2>
  <img src="morning nasta/poha upma.jpg" alt="poha upma ">
  <p> Morning Nasta of poha upma  with , Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$8.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Pasta</h2>
  <img src="morning nasta/pasta.webp" alt="Pasta ">
  <p> Morning Nasta of Pasta  with Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$10.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Jalebi Samosha</h2>
  <img src="morning nasta/samosa.jpg" alt="jalebi samosha">
  <p> Morning Nasta of samosha, Chutni and hary mirch. 😋😋 </p>
  <span class="price">$30.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Naan </h2>
  <img src="morning nasta/naan.jpg" alt="jalebi samosha">
  <p> Morning Nasta Naan is a leavened, oven-baked flatbread. 😋😋 </p>
  <span class="price">$12.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>

</section>
<div class="menu1">
  <h1>MENU</h1>
   
   <h1 style="color: red;">LUNCH AND DINNER</h1>
    <p>Explore our delicious menu</p>
</div>
  <section class="menu">
    <div class="menu-item">
        <h2>Daalchaawalroti</h2>
        <img src="morning nasta/daalchaawalroti.jpg" alt="daalchaawalroti">
        <p>Lunch  of Daal Chaawal Roti Hari  mirchi  and  Onion. 😋😋😋 </p>
        <span class="price">$12.99</span>
        <button class="order-btn"><a href="cart.php">Order Now</button>
    </div>
    <div class="menu-item">
        <h2>Chicken Chawal</h2>
        <img src="morning nasta/chicken chawal.jpg" alt="chicken chawal">
        <p>Chicken Chawal with  Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$20.99</span>
        <button class="order-btn"><a href="cart.php">Order Now</button>
    </div>
    <div class="menu-item">
        <h2>Chicken-Pulao</h2>
        <img src="morning nasta/Chicken-Pulao.jpg" alt="Chicken-Pulao ">
        <p>Chicken-Pulao with Chutni , Hari mirchi and Onion. 😋😋 </p>
        <span class="price">$30.99</span>
        <button class="order-btn"><a href="cart.php">Order Now</button>
    </div>
    <div class="menu-item">
      <h2>Dal-Chawal-Aloo-ki-Bhunjia</h2>
      <img src="morning nasta/Dal-Chawal-Aloo-ki-Bhunjia.webp" alt="Dal-Chawal-Aloo-ki-Bhunjia ">
      <p> Dal-Chawal-Aloo-ki-Bhunjia Hari mirchi and Onion. 😋😋 </p>
      <span class="price">$8.99</span>
      <button class="order-btn">Order Now</button>
  </div>
  <div class="menu-item">
    <h2>Daal-Rice-Ghee</h2>
    <img src="morning nasta/dal-rice-ghee.jpg" alt="dal-rice-ghee">
    <p> Daal-Rice-Ghee Hari mirchi and Onion. 😋😋 </p>
    <span class="price">$12.99</span>
    <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Egg Biryani</h2>
  <img src="morning nasta/Egg Biryani.jpg" alt="Egg Biryani ">
  <p>Egg Biryani Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$15.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Eggs Chaawal</h2>
  <img src="morning nasta/eggs chawal.jpg" alt="Egg chaawal ">
  <p> Eggs Chaawal with Hari mirchi and Onion. 😋😋 </p>
  <span class="price">$20.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Gur-walay-Chawal</h2>
  <img src="morning nasta/Gur-walay-Chawal.webp" alt="Gur-walay-Chawal">
  <p>Gur-walay-Chawal 😋😋 </p>
  <span class="price">$10.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
<div class="menu-item">
  <h2>Fish fry</h2>
  <img src="morning nasta/fish.jpg" alt="Gur-walay-Chawal">
  <p>Fish fry is a meal containing battered or breaded fried fish. 😋😋 </p>
  <span class="price">$10.99</span>
  <button class="order-btn"><a href="cart.php">Order Now</button>
</div>
</section>

  
  <!-- Hamburger -->
 
  <section class="home" id="home">
    <div class="content">
      <h1>Order Your Product <span class="yellow">Easier & Faster.</span></h1>
      <p>
        Delivero is a leading global online food delivery marketplace,
        connecting consumers and restaurants through its platform in 24
        countries.
      </p>
      <a href="#" class="home-btn">Go to Menu</a>
    </div>
    <div class="image">
      <img src="Delivery address.svg" alt="" />
    </div>
  </section>

    <!-- Preloader -->
    <div class="preloader">
        <img src="preloader.gif" alt="" />
      </div>
  
    <!-- Header -->

    <!-- Home -->

    <!-- Services -->
    <section class="services" id="services">
        <div class="top">
          <h2><span class="yellow">Why</span> We are the Best</h2>
       
       <strong><p>1. Fast and Reliable Delivery:</strong> Quick, dependable delivery times ensure customers get their food hot and fresh.</p><br>
       <strong><p>2.Wide Selection: </strong>Offering a broad range of restaurant options and cuisines can cater to diverse customer tastes.</p><br>
       <strong><p>3.User-Friendly App: </strong>An intuitive, easy-to-navigate app or website makes ordering simple and efficient.</p><br>
        <strong><p>4.Customer Service:</strong>Excellent support, including responsive handling of issues and feedback, contributes to a po</p><br>
       <strong><p>5.Quality Control: </strong>Ensuring food quality and accuracy in orders is crucial.</p><br>
       <strong><p>6.Competitive Pricing: </strong>Offering good value, whether through reasonable delivery fees or promotions, attracts customers.</p><br>
       <strong><p>7.Safety and Hygiene:</strong> Emphasizing cleanliness and safety, especially in food handling and delivery, builds trust.</p><br>
       <strong><p>8.Innovative Features: </strong>Unique offerings like real-time tracking, customization options, or loyalty rewards can set you apart.</p><br>
      </div>
  
        <div class="bottom">
          <div class="box">
            <img src="delivery-man.svg" alt="" />
            <h4>Free Delivery</h4>
            <p>
              Enjoy the convenience of free delivery on all orders! No minimum purchase required—just delicious food delivered straight to your door at no extra cost. We’re committed to providing you with a seamless and satisfying dining experience without the added delivery fees. Order now and savor your favorites for free!
            </p>
            <a href="#">View More <img src="btn-arrow.svg" alt="" /> </a>
          </div>
          <div class="box">
            <img src="fast-food.svg" alt="" />
            <h4>Healthy Foods</h4>
            <p>
e prioritize your well-being by offering a selection of healthy foods. Our menu features fresh fruits, vegetables, whole grains, and lean proteins, all crafted to support your health goals. Enjoy nourishing, delicious options that fuel your body and enhance your overall wellness with every bite.              At [Deliveroo], w
            </p>
            <a href="#">View More <img src="btn-arrow.svg" alt="" /> </a>
          </div>
          <div class="box">
            <img src="order-food.svg" alt="" />
            <h4>Online Ordering</h4>
            <p>
              At [Deliveroo], online ordering is simple and convenient. Browse our menu, customize your selections, and place your order from the comfort of your home. Enjoy quick, efficient service with real-time updates and secure payment options. Experience seamless dining with just a few clicks—order online today!
            </p>
            <a href="#">View More <img src="btn-arrow.svg" alt="" /> </a>
          </div>
        </div>
      </section>
  
    <!-- About #1 -->
    <section class="about" id="about">
        <div class="image">
          <img src="illus riding.svg" alt="" />
        </div>
        <div class="content">
          <h3><span class="yellow">Order</span> anytime and anywhere</h3>
          <p>
            Order anytime and anywhere with ease at [Deliveroo ]! Our flexible online platform allows you to place orders from the comfort of your home, office, or even on the go. Whether you're craving a late-night snack or planning your meals ahead, our service is available 24/7. Enjoy the freedom to customize your order and have it delivered right to your door, whenever it suits you. No matter where you are, deliciousness is just a few clicks away. Experience unparalleled convenience with our anytime, anywhere ordering—your favorite meals are always within reach!
          </p>
          <a href="#" class="btn">Make an Offer</a>
        </div>
      </section>
  
    <!-- About #2 -->

    <!-- About #3 -->
    <section class="about about-2">
        <div class="content">
          <h3>
            <span class="yellow">Deliver</span> the products with best safety
          </h3>
          <p>
            "Ensure your products arrive in perfect condition with our top-notch safety measures. We use secure packaging, reliable carriers, and careful handling at every step to protect your items during transit, guaranteeing they reach you safely and intact."
          </p>
          <a href="#" class="btn">Make an Offer</a>
        </div>
  
        <div class="image">
          <img src="illus deliver.svg" alt="" />
        </div>
      </section>
      <section class="about about-3" style="gap: 3rem 13rem">
        <div class="image">
          <img src="buying online.svg" alt="" />
        </div>
  
        <div class="content">
          <h3><span class="yellow">Track</span> your order very easily</h3>
          <p>
            "Effortlessly track your order with our user-friendly system. Just enter your tracking number to get real-time updates on your package's location and estimated delivery time."
          </p>
          <a href="#" class="btn">Track Now</a>
        </div>
      </section>
  
    <!-- App -->
    <section class="app" id="contact">
        <div class="image">
          <img src="splash with mobile.svg" alt="" />
        </div>
        <div class="content">
          <h3>Place your order through our app</h3>
          <p>
            You can easily place your order using our mobile app. Now you can
            download our app for both IOS and Android mobiles.
          </p>
          <div class="links">
            <img src="app-store.png" alt="" />
            <img src="google-play.png" alt="" />
          </div>
        </div>
      </section>
      
  
    <!-- Footer -->
    <footer class="footer">
        <div class="top">
          <div class="content">
            <a href="" class="logo">Delive<span class="yellow">roo</span></a>
            <p>
             
            </p>
          </div>
  
          <div class="links">
            <div class="link">
              <h4>Contact Information</h4>
              <div>
                <img src="location-cross.svg" alt="" />
                <span>Patna,(Bihar),800004</span>
              </div>
              <div>
                <img src="sms-tracking.svg" alt="" />
                <span>deliveroo@gmail.com</span>
              </div>
            </div>
  
            <div class="link">
              <h4>Quick Links</h4>
              <a href="#">Services</a>
              <a href="#">About Us</a>
              <a href="#">Contact Us</a>
              <a href="#">Download</a>
            </div>
  
            <div class="link">
              <h4>Legal</h4>
              <a href="#">Privacy Policy</a>
              <a href="#">Term of Use</a>
              <a href="#">Conditions</a>
              <a href="#">Location</a>
            </div>
  
            <div class="link">
              <h4>Connect with Us</h4>
              <div>
                <img src="instagram.svg" alt="" />
                <span>Instagram</span>
              </div>
              <div>
                <img src="twitter.svg" alt="" />
                <span>Twitter</span>
              </div>
              <div>
                <img src="facebook.svg" alt="" />
                <span>Facebook</span>
              </div>
            </div>
          </div>
        </div>
        <div class="bottom">
          <p>Copyright © 20120-2025 Deliveroo Company  All rights reserved.</p>
        </div>
      </footer>
  
    <!-- Go To Top -->
    <div class="scroll-top">
        <img src="./images/arrow-up-outline.svg" alt="" />
      </div>
  
    <!-- Scripts -->
   
    <script src="foodfair.js"></script>

  </body>
</html>
