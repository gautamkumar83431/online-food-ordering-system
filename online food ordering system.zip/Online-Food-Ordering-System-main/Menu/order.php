<?php
include('session_start.php');
$conn = mysqli_connect('localhost','root','','gautam_foods');

if ($conn == false) 
{
    echo "Database connection failed";
}
$menu_items = [
    1 => ["name" => "Chai Bhajya", "price" => 12.99],
    2 => ["name" => "Daalwada", "price" => 8.99],
    3 => [ "name" => "Jalebi Samosha", "price" => 10.99],
 4 => ["name" => "chana salad", "price" => 15.99],
 5 => ["name" => "jeri Puri Tarkari", "price" => 20.99],
 6=> ["name" => "poha upma", "price" => 8.99],
 7=> ["name" => "Pasta", "price" => 10.99],
 8=>[ "name" => "Jalebi Samosha", "price" => 30.99],
 9=>[ "name" => "Naan", "price" => 12.99],
    10=>  ["name" => "Daalchaawalroti", "price" => 12.99],
 11=> [ "name" => "Chicken Chawal", "price" => 20.99],
 12=> [ "name" => "Chicken-Pulao", "price" => 30.99],
   
    13 =>  ["name" => "Dal-Chawal-Aloo-ki-Bhunjia", "price" => 8.99],
 14=>  ["name" => "Daal-Rice-Ghee", "price" => 12.99],
 15   => [ "name" => "Egg Biryani", "price" => 15.99],
 16=> [ "name" => "Eggs Chaawal", "price" => 20.99],
 17=> [ "name" => "Gur-walay-Chawal", "price" => 10.99],
 18=> [ "name" => "Fish fry", "price" => 10.99],
 19=> [ "name" => "Daalchaawalroti", "price" => 12.99],
20 => [ "name" => "Chicken Chawal", "price" => 20.99],
 21=> [ "name" => "Chicken-Pulao", "price" => 30.99],
 22=> [ "name" => "Dal-Chawal-Aloo-ki-Bhunjia ", "price" => 8.99],
 23=> [ "name" => "Daal-Rice-Ghee ", "price" => 12.99],
24 => [ "name" => "Egg Biryani", "price" => 15.99],
 25=> [ "name" => "Eggs Chaawal", "price" => 20.99],
 26=> [ "name" => "Gur-walay-Chawal", "price" => 10.99]
];


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['item_id'], $_POST['quantity'])) {
    $item_id = (int) $_POST['item_id'];
    $quantity = (int) $_POST['quantity'];

    if (isset($menu_items[$item_id])) {
        if (isset($_SESSION['cart'][$item_id])) {
            $_SESSION['cart'][$item_id] += $quantity;
        } else {
            $_SESSION['cart'][$item_id] = $quantity;
        }
    }
    header("Location: add product into cart.php");
    exit;
}
?>
